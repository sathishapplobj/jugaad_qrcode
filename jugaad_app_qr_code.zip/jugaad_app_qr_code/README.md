#INTRODUCTION:

> The Endroid QR Code module enables to generate a QR Code image.
> Just pass the full url in the field to get QR Image.